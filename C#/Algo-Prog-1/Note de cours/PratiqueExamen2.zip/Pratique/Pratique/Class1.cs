﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pratique
{
    class Class1
    {
        private static int D = 3;
        private int A = 4;
        private int B = 5;
        private int U = 2;
        private int C = 1;
        public int G = 8;
        private int H = 2;
        public int M = 3;


        public int PP1
        {
            get
            {
                if (C > 5)
                    return C;
                else
                    return A;
            }
            set
            {
                C = C + value;
                A = B + C;
            }
        }
        public static int PP2
        {
            get
            {
                return D;
            }
            set
            {
                D = value;
            }
        }
        public int PP9
        {
            get
            {
                int R;
                R = U + 1;
                return R;
            }


            set
            {
                int R;
                R = U + value;
                U = R;
            }
        }
        public Class1()
        {
            H = 25;
        }
        public Class1(int param)
        {
            if (param == 0)
                param = 3;
            H = 22 + param;
        }
        public Class1(int param1, int param2)
        {
            if (param1 == 0)
            {
                param1 = 4;
                param2 = 4;
            }
            H = 20 + param1 + param2;
        }

        public void MethodeAddH(int param)
        {
            H = H + param;
        }


        public int MethodeRetourH()
        {
            return H;
        }

    }
}

