﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pratique
{
    class Program
    {
        static void Methode111PourTryCatch(ref int paramR4)
        {
            try
            {
                paramR4 = paramR4 + 6;
                Convert.ToInt32("34erw6");
                paramR4 = paramR4 + 11;
            }

            catch (Exception)
            {
                paramR4 = paramR4 + 111;
                throw;
                paramR4 = paramR4 + 222;
            }
            finally
            {
                paramR4 = paramR4 + 5;
            }
            paramR4 = paramR4 + 54;

        }

        static void Methode222PourTryCatch(ref int paramR5)
        {
            try
            {
                paramR5 = paramR5 + 7;
                Convert.ToInt32("5");
                paramR5 = paramR5 + 10;
            }

            catch (Exception)
            {
                paramR5 = paramR5 + 101;
                throw;
                paramR5 = paramR5 + 202;
            }
            finally
            {
                paramR5 = paramR5 + 8;
            }
            paramR5 = paramR5 + 50;

        }


        static void Main()
        {
            int R;
            MaClasse OB1 = new MaClasse();
            MaClasse OB2 = new MaClasse();
            Class1 OB3 = new Class1();
            Class1 OB4 = new Class1();
            OB3.MethodeAddH(8);

            OB1.PP1 = 4;
            R = OB1.PP1;
            Console.WriteLine("Question 01 = {0}", R);

            Class1.PP2 = 9;
            R = MaClasse.PP2;
            Console.WriteLine("Question 02 = {0}", R);


            MaClasse.PP2 = 5;
            OB1.Met01();
            OB2.Met01();
            R = MaClasse.PP2;
            Console.WriteLine("Question 03 = {0}", R);

            OB3.G = OB3.G + 4;
            OB4.G = OB4.G + 6;
            R = OB3.G;
            Console.WriteLine("Question 04 = {0}", R);
            R = OB4.G;
            Console.WriteLine("Question 05 = {0}", R);

            OB2.PP3 = 7;
            R = OB1.Met02(5);
            Console.WriteLine("Question 06 = {0}", R);

            OB1.M = OB3.M + OB1.M;
            R = OB1.M;
            Console.WriteLine("Question 07 = {0}", R);

            R = OB3.MethodeRetourH();
            Console.WriteLine("Question 08 = {0}", R);

            OB2.PP4 = 4;
            R = OB2.PP4;
            Console.WriteLine("Question 09 = {0}", R);

            R = OB3.PP9;
            Console.WriteLine("Question 10 = {0}", R);

            SortedList Chest = new SortedList();

            Chest.Add("Poitrine", "Bras");
            Chest.Add("Bras", "Poitrine");
            Chest.Add("Dos", "Dos");
            Chest.Add("Jambe", "A oublier");

            int Index = 0;
            string Resultat;

            Resultat = (string)Chest.GetByIndex(Index);
            Console.WriteLine("Question 11 = {0}", Resultat);

            foreach (string RRR in Chest.Values)
            {
                Resultat = RRR;
            }
            Console.WriteLine("Question 12 = {0}", Resultat);

            Index = Chest.IndexOfKey("Bras");
            Resultat = (string)Chest.GetByIndex(Index);
            Console.WriteLine("Question 13 = {0}", Resultat);

            Chest.Remove("Jambe");
            Console.WriteLine("Question 14 = {0}", Chest.Count);

            Chest.Add("Doigt", "Pouce");
            Chest.Add("Orteil", "Pied");
            Console.WriteLine("Question 15 = {0}", Chest.Count);

            int R1 = 0;
            int R2 = 0;
            int R3 = 0;
            int R4 = 0;
            int R5 = 0;


            try
            {
                R1 = R1 + 2;
                Convert.ToInt32("ABC");
                R1 = R1 + 11;
            }

            catch (Exception)
            {
                R1 = R1 + 30;
            }

            finally
            {
                R1 = R1 + 1;
            }
            R1 = R1 + 22;

            try
            {
                R2 = R2 + 2;
                int aaaa = 0;
                aaaa = aaaa + 11;
                R2 = R2 + 11;
            }

            catch (Exception)
            {
                R2 = R2 + 5;
            }

            finally
            {
                R2 = R2 + 7;
            }
            R2 = R2 + 10;

            try
            {
                R3 = R3 + 3;
                Convert.ToInt32("ABC");
                R3 = R3 + 13;
            }

            catch (FormatException)
            {
                R3 = R3 + 9;
            }
            catch (OverflowException)
            {
                R3 = R3 + 22;
            }
            catch (Exception)
            {
                R3 = R3 + 30;
            }

            try
            {
                R4 = 0;
                Methode111PourTryCatch(ref R4);
            }
            catch (Exception)
            {
                R4 = R4 + 4;
            }



            try
            {
                R5 = 0;
                Methode222PourTryCatch(ref R5);
            }
            catch (Exception)
            {
                R5 = R5 + 3;
            }

            Console.WriteLine("Question 16 = {0}", R1);
            Console.WriteLine("Question 17 = {0}", R2);
            Console.WriteLine("Question 18 = {0}", R3);
            Console.WriteLine("Question 19 = {0}", R4);
            Console.WriteLine("Question 20 = {0}", R5);

            Console.ReadLine();
        }
    } 

}
