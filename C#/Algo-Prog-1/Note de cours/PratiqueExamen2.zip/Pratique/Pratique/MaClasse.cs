﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pratique
{
    class MaClasse
    {
        private static int D = 3;
        private int A = 1;
        private int B = 5;
        private int C = 4;
        private int K = 7;
        public int M = 5;


        public int PP1
        {
            get
            {
                if (C > 5)
                    return C;
                else
                    return A;
            }
            set
            {
                C = C + value;
                A = B + C;
            }
        }
        public static int PP2
        {
            get
            {
                return D;
            }
            set
            {
                D = value;
            }
        }
        public int PP4
        {
            get
            {
                int R;
                R = B + 3;
                return R;
            }
            set
            {
                int R;
                R = B + value;
                B = R;
            }
        }

        public int PP3
        {
            set
            {
                K = value;
            }
        }

        public void Met01()
        {
            D = D + 7;
        }

        public int Met02(int param)
        {
            int x;
            x = K + param;
            return x;
        }
    }
}
