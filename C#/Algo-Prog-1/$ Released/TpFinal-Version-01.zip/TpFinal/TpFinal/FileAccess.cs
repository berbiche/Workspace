﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TpFinal
{
    class FileAccess
    {
        #region Variables
        //load le dictionnaire des taches et des utilisateurs
        private static List<Tache> listeTache = new List<Tache>(); //je vais accéder aux éléments via des méthodes publiques
        private static Dictionary<int, string> dictionnaireEmploye = new Dictionary<int, string>(); //pareil qu'en-haut
        public static readonly string tacheModele = string.Format("{0,-6}\t{1,-30}\t{2,-10}\t{3,-10}\t{4,-20}\t{5,-10}\r\n{6}\t{7}\t{8}\t{9}\t{10}\t{11}", "ID", "Description", "Statut", "Assigné à", "Requête", "Fin", "------", "------------------------------", "----------", "----------", "--------------------", "----------"), tacheModeleConsole = string.Format("{0,-6}\t{1,-30}\t{2,-10}\t{3,-20}\t{4,-30}\t{5,-10}\r\n{6}\t{7}\t{8}\t{9}\t{10}\t{11}", "ID", "Description", "Statut", "Assigné à", "Requête", "Fin", "------", "------------------------------", "----------", "--------------------", "------------------------------", "----------"),
            employeModele = string.Format("{0,-7}\t{1,-20}\r\n{2,-7}\t{3,-30}", "ID", "NOM", "-------", "------------------------------");
        #endregion

        #region Accesseurs
        public static int dernierIdentifiantTache { get { return listeTache.Last().idtache; } }
        #endregion

        #region Accès aux fichiers
        /// <summary>
        /// Charge la liste des employés et des tâches dans leur dictionnaire respectif
        /// </summary>
        public static void loadFiles()
        {
            foreach (string lines in File.ReadLines(@"..\..\Data\employes.txt").Skip(2))
            {
                var matches = Regex.Matches(lines.Trim(), "[\\S ]+"); //fonctionne avec les noms composés
                int id = int.Parse(matches[0].Value);
                string nomComplet = matches[1].Value;
                if (!dictionnaireEmploye.ContainsKey(id))
                    dictionnaireEmploye.Add(id, nomComplet);
                else
                    dictionnaireEmploye.Add(id + 10, nomComplet);
            }
            foreach (string lines in File.ReadLines(@"..\..\Data\taches.txt").Skip(2))
            {
                var matches = Regex.Matches(lines.Trim(), "[\\S ]+");
                int idAssigne, idTache, idCreateur;
                int.TryParse(matches[0].Value, out idTache);
                string description = matches[1].Value.Trim();
                int.TryParse(matches[3].Value.Trim(), out idAssigne);
                //état de la tache
                int etat = 0;
                switch (matches[2].Value.Trim())
                {
                    case "En attente":
                        etat = 0;
                        break;
                    case "En exéc.":
                        etat = 1;
                        break;
                    case "Terminé":
                        etat = 2;
                        break;
                    case "Annulé":
                        etat = 3;
                        break;
                }
                //parse le nom du créateur ainsi que la date de la création
                var a = matches[4].Value;
                string nom = Regex.Replace(a, "[^ ]+$", ""); //@"[a-zA-Z][a-zA-Z .]+(?!\()"
                int.TryParse(nom.Trim(), out idCreateur);
                nom = Regex.Replace(a, "^[0-9 ]+|[()]", "");
                var date = nom.Split('-');
                DateTime creation = new DateTime(year: int.Parse(date[0]), month: int.Parse(date[1]), day: int.Parse(date[2]));
                DateTime? fin = null;

                //parse la date de la fin de la tâche
                if (matches.Count == 6)
                {
                    var datefin = matches[5].Value.Split('-');
                    fin = new DateTime(year: int.Parse(datefin[0]), month: int.Parse(datefin[1]), day: int.Parse(datefin[2]));
                }

                //Création des instances de la classe tâche
                listeTache.Add(new Tache(idTache, description, etat, idCreateur, idAssigne, creation, fin));
            }
        }

        /// <summary>
        /// Sauvegarde les modifications dans les fichiers chaque fois qu'une modification est apportée au dictionnaire
        /// </summary>
        public static void saveToFiles()
        {
            StreamWriter employe = new StreamWriter(@"..\..\Data\employes.txt"), tache = new StreamWriter(@"..\..\Data\taches.txt");
            employe.AutoFlush = true; tache.AutoFlush = true;
            employe.WriteLine(employeModele);
            foreach (var trucs in dictionnaireEmploye)
            {
                employe.WriteLine("{0,-7}\t{1,-30}", trucs.Key, trucs.Value);
            }
            tache.WriteLine(tacheModele);
            foreach (var trucs in listeTache)
            {
                tache.WriteLine(trucs.Verbalisation('1'));
            }
        }
        #endregion

        #region Méthodes de recherche et autres
        /// <summary>
        /// Regarde si la clé spécifiée existe dans la liste d'employées
        /// </summary>
        /// <param name="identifiant">clé unique de l'utilisateur</param>
        /// <returns>Vrai si l'identifiant unique existe sinon faux</returns>
        public static bool cleExistanteEmploye(int identifiant)
        {
            return dictionnaireEmploye.ContainsKey(identifiant);
        }

        /// <summary>
        /// Retourne l'identifiant de la personne possédant l'identifiant unique passé en paramètre
        /// </summary>
        /// <param name="identifiant">Identifiant unique de l'employé</param>
        /// <returns>Nom de la personne pour l'identifiant</returns>
        public static string trouverEmploye(int identifiant)
        {
            return dictionnaireEmploye.ContainsKey(identifiant) ? dictionnaireEmploye[identifiant] : null;
        }

        /// <summary>
        /// Créé une nouvelle tâche
        /// </summary>
        /// <param name="description">Description de la tâche</param>
        /// <param name="idAssigne">Identifiant unique de la personne assignée</param>
        public static void createTache(string description, int idAssigne)
        {
            listeTache.Add(new Tache(description, idAssigne));
        }

        /// <summary>
        /// Recherche si la clé existe dans la liste des tâches
        /// </summary>
        /// <param name="identifiant">L'identifiant unique de la clé</param>
        /// <returns>vrai: identifiant existe, faux: n'existe pas</returns>
        public static bool tacheExistante(int identifiant)
        {
            return listeTache.Exists(x => x.idtache == identifiant);
        }

        /// <summary>
        /// Place en ordre les tâches terminées et retourne les 3 plus récentes
        /// </summary>
        /// <param name="a">2:termine, 3:annule</param>
        /// <returns>string contenant la(les) dernière(s) tâche(s) terminée(s)</returns>
        public static string troisTermineOuAnnule(int a)
        {
            return string.Join("\n", listeTache
                .Where(x => x.dateFinale.HasValue && x.etatCourant == a) //sélectionne les éléments non nuls
                .OrderByDescending(x => x.dateFinale.Value) //mis en ordre par leur date
                .Take(3) //prend les 3 premiers éléments
                .Select(x => x.Verbalisation()));
        }

        /// <summary>
        /// Retourne une liste de tous les éléments selon le type
        /// </summary>
        /// <param name="a">0:enAttente,1:enCours,2:termine,3:annule</param>
        /// <returns>Tous les éléments satisfaisant à la tâche</returns>
        public static string getByEtat(int a)
        {
            return string.Join("\n", listeTache.Where(x => x.etatCourant == a).Select(x => x.Verbalisation()));
        }

        /// <summary>
        /// Retourne la liste de toutes les tâches
        /// </summary>
        /// <returns>string contenant toutes les tâches formatés</returns>
        public static string getAllTache()
        {
            return string.Join("\n", listeTache.Select(x => x.Verbalisation()));
        }
        /// <summary>
        /// Retourne un string formaté de la tâche spécifiée si trouvé
        /// </summary>
        /// <param name="identifiant">Identifiant unique de la tâche</param>
        /// <returns>Verbalisation de la tâche spécifiée sinon null</returns>
        public static string getTache(int identifiant)
        {
            return listeTache.Find(x => x.idtache == identifiant).Verbalisation(); //retourne null si rien trouvé
        }

        /// <summary>
        /// Modifie l'état d'une tâche
        /// </summary>
        /// <param name="identifiant">L'identifiant de la tâche</param>
        /// <param name="choix">0: terminate, 1: Cancel, 2: StartAgain, 3: Wait</param>
        /// <returns>Vrai si l'opération est réussi</returns>
        public static bool modifierTache(int identifiant, int choix)
        {
            if (tacheExistante(identifiant))
            {
                var abc = listeTache.FindIndex(x => x.idtache == identifiant);
                try
                {
                    if (choix == 0)
                        return listeTache[abc].Terminate();
                    else if (choix == 1)
                        return listeTache[abc].Cancel();
                    else if (choix == 2)
                        return listeTache[abc].StartAgain();
                    else if (choix == 3)
                        return listeTache[abc].Wait();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return false;
        }
        #endregion
    }
}
