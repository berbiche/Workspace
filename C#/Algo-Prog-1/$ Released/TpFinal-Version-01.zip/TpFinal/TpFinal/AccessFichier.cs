﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpFinal
{
    class AccessFichier
    {
        //charge le contenu des fichiers dans un string
        static string[] tableauTache = File.ReadAllLines("\\tache.txt"), tableauEmploye = File.ReadAllLines("\\employe.txt");
        //parse le tableau des tâches
    }
}
