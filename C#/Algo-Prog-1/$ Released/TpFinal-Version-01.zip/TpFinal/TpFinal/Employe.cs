﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpFinal
{
    // TODO: implémentez une méthode pour ajouter des utilisateurs au fichier contenant les utilisateurs
    class Employe
    {
        private string nomComplet;
        private int id;
        public int ID { get { return this.id; } }
        public string nom { get {return this.nomComplet; } }
        public Employe(string nomComplet, int id)
        {
            this.nomComplet = nomComplet;
            this.id = id;
        }
    }
}
